#pragma once
// Sélection du test actif
constexpr int TEST = 1;  // 1=Smooth + DZ variable, 2=Stub motor, 3=Stub PID
