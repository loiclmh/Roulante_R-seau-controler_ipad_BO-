#pragma once
#include <Arduino.h>
#include "hal_serial.h"

// SLIP constants (RFC1055)
static constexpr uint8_t SLIP_END     = 0xC0;
static constexpr uint8_t SLIP_ESC     = 0xDB;
static constexpr uint8_t SLIP_ESC_END = 0xDC;
static constexpr uint8_t SLIP_ESC_ESC = 0xDD;

// Encode (host ← Pico)
inline void slipWriteByte(uint8_t b) {
  using namespace HALSerial;
  if (b == SLIP_END)      { write(SLIP_ESC); write(SLIP_ESC_END); }
  else if (b == SLIP_ESC) { write(SLIP_ESC); write(SLIP_ESC_ESC); }
  else                    { write(b); }
}
inline void slipWritePacket(const uint8_t* data, size_t len) {
  using namespace HALSerial;
  write(SLIP_END);
  for (size_t i=0;i<len;i++) slipWriteByte(data[i]);
  write(SLIP_END);
}

// Decode (optionnel pour plus tard)
struct SlipDecoder {
  uint8_t buf[128];
  size_t  len = 0;
  bool    esc = false;

  // retourne true quand un paquet complet est reçu (dans buf,len)
  bool poll() {
    using namespace HALSerial;
    while (available()) {
      int r = read();
      if (r < 0) break;
      uint8_t b = (uint8_t)r;
      if (b == SLIP_END) {
        if (len > 0) { size_t L=len; len=0; esc=false; return true; } // paquet prêt
        else { len=0; esc=false; } // ignore END doublés
      } else if (b == SLIP_ESC) {
        esc = true;
      } else {
        if (esc) {
          if (b == SLIP_ESC_END) b = SLIP_END;
          else if (b == SLIP_ESC_ESC) b = SLIP_ESC;
          esc = false;
        }
        if (len < sizeof(buf)) buf[len++] = b; // sinon: tronque
      }
    }
    return false;
  }
};
