#pragma once
#include <Arduino.h>

namespace HALSerial {
  inline void begin() {
    Serial.begin(1000000);        // valeur ignorée en USB CDC, mais ok pour compat
    while (!Serial) delay(10);    // attendre le port USB
  }
  inline bool available() { return Serial.available() > 0; }
  inline int  read()      { return Serial.read(); }
  inline void write(uint8_t b) { Serial.write(b); }
  inline void write(const uint8_t* buf, size_t n) { Serial.write(buf, n); }
  inline void flush() { Serial.flush(); }
}
