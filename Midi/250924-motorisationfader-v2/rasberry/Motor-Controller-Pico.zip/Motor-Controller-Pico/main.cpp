// main.cpp
#if __has_include(<Adafruit_TinyUSB.h>)
  #include <Adafruit_TinyUSB.h> // facultatif: permet de basculer TinyUSB plus tard
#endif

#include <Arduino.h>
#include "pins.h"
#include "hal_serial.h"
#include "slip.h"
#include "display.h"

// ------- Helpers LE (pour Tuning.py : int16 little-endian) -------
static inline void put_i16_le(uint8_t* dst, int16_t v) {
  dst[0] = (uint8_t)(v & 0xFF);
  dst[1] = (uint8_t)((v >> 8) & 0xFF);
}

// ------- Etat appli -------
static SlipDecoder rx;            // décodeur SLIP entrant
static bool experimentOn = false; // passera à true quand on reçoit 's'
static int  counterOLED = 0;      // pour l'affichage

// ------- Traitement d'un paquet SLIP entrant -------
// Format attendu (host -> Pico) : cmd(1B) + fader('0'..'3')(1B) + [float32 LE](4B) optionnel
static void handlePacket(const uint8_t* p, size_t n) {
  if (n < 2) return;
  const char cmd = (char)p[0];
  const char faderIdx = (char)p[1];
  (void)faderIdx; // non utilisé pour l'instant

  switch (cmd) {
    case 's': // start experiment
      experimentOn = true;
      Display::showMessage("Start exp (s)");
      break;

    // NOTE: on ignorera p/i/d/c/m pour l’instant (on les branchera plus tard)
    default:
      // Display::showMessage("Cmd recu"); // décommenter si tu veux un feedback
      break;
  }
}

void setup() {
  // I/O de base
  pinsBegin();

  // USB CDC Serial (Pico SDK stack)
  HALSerial::begin();

  // OLED
  Display::begin();
  Display::showMessage("Hello Pico");
  Display::showMessage("Waiting 's' from PC");

  // LED debug OFF
  digitalWrite(PIN_DEBUG_LED, LOW);
}

void loop() {
  // ----------- Réception SLIP ----------
  if (rx.poll()) {
    handlePacket(rx.buf, rx.len);
  }

  // ----------- Boucle fixe 1 kHz ----------
  static uint32_t last_us = 0;
  uint32_t now = micros();
  if (now - last_us >= 1000) { // 1 kHz
    last_us += 1000;

    // Dès qu'on a reçu 's', on publie des données factices (sinus) pour vérifier le flux.
    if (experimentOn) {
      static int16_t t = 0;
      t += 20; // vitesse défilement
      float s = sinf(t * 0.005f);        // -1..1 (ref)
      float p = sinf(t * 0.005f + 0.5f); // position simulée
      float u = 0.6f * sinf(t * 0.005f + 1.0f); // commande simulée

      // Mise à l’échelle vers int16
      int16_t ref_i16 = (int16_t)(s * 30000);
      int16_t pos_i16 = (int16_t)(p * 30000);
      int16_t u_i16   = (int16_t)(u * 30000);

      uint8_t payload[6];
      put_i16_le(&payload[0], ref_i16);
      put_i16_le(&payload[2], pos_i16);
      put_i16_le(&payload[4], u_i16);

      slipWritePacket(payload, sizeof(payload));
      HALSerial::flush();

      // petit clignotement LED pour montrer l’activité
      static bool led = false;
      led = !led;
      digitalWrite(PIN_DEBUG_LED, led);
    }
  }

  // ----------- Affichage OLED basique (toutes ~1 s) ----------
  static uint32_t last_ms = 0;
  uint32_t now_ms = millis();
  if (now_ms - last_ms >= 1000) {
    last_ms = now_ms;
    Display::showCounter(counterOLED++);
  }
}
