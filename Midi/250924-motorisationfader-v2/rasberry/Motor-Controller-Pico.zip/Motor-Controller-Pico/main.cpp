#if __has_include(<Adafruit_TinyUSB.h>)
  #include <Adafruit_TinyUSB.h>
#endif

#include <Arduino.h>
#include "pins.h"
#include "hal_serial.h"
#include "display.h"
#include "motor.hpp"         // fusionné: pas de .h séparé
#include "ref_profile.hpp"   // fusionné: pas de .h séparé
// #include "pid.h"          // non utilisé en OPEN_LOOP_TEST

// ====== Choix du mode ======
#define OPEN_LOOP_TEST 0  // 1 = fader -> moteur direct (sans PID), 0 = profil/ref + SLIP/PID (à activer plus tard)

// Boucle fixe 1 kHz
static inline bool tick1k() {
  static uint32_t last = 0;
  uint32_t now = micros();
  if ((uint32_t)(now - last) >= 1000) { last += 1000; return true; }
  return false;
}

void setup() {
  pinsBegin();
  HALSerial::begin();
  Display::begin();
  Display::showSplash("Fader test\nOpen-loop");

  Motor::begin();

  analogReadResolution(12); // RP2040 ADC 0..4095
}

void loop() {
#if OPEN_LOOP_TEST
  // ==== Mode test câblage : fader -> moteur (sans PID) ====
  if (tick1k()) {
    uint16_t raw12 = analogRead(PIN_FADER_WIPER); // 0..4095
    uint16_t y10   = raw12 >> 2;                  // 0..1023
    static float ema = 0.0f;
    ema = 0.3f * y10 + 0.7f * ema;

    // map 0..1023 -> -1000..+1000 (centre ~512)
    int16_t u = map((int)ema, 0, 1023, -1000, 1000);
    Motor::drive(u);

    // UI ~20 Hz
    static uint32_t t_ui = 0;
    uint32_t now = millis();
    if (now - t_ui >= 50) {
      t_ui = now;
      Display::showFaderAndMotor((uint16_t)ema, y10, u);
    }
  }
#else
  // ==== Mode expérience (PID + profil TTTapa) ====
  // (Garde pour plus tard — ici on se concentre sur le câblage fader/moteur)
#endif
}
