#pragma once
// Select active test (1 only implemented here)
#define TEST 1  //0=Normal  1=Fader + OLED, 2=Stub, 3=Stub
