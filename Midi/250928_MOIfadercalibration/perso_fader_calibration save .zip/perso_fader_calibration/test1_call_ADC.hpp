#pragma once
#if TEST == 1
#include <Arduino.h>
#include "calibration.h"
#include "comms.hpp"

// Accès aux dernières valeurs mises à jour par ADC_FADER()
extern volatile int gLastRaw[NUM_FADERS];
extern volatile int gLastOut8[NUM_FADERS];

// OLED optionnelle (définir HAVE_OLED et fournir un objet display ailleurs)
#ifdef HAVE_OLED
  #include <Adafruit_SSD1306.h>
  extern Adafruit_SSD1306 display;
#endif

// --- Aide ---
static inline void test1_fader_ADC_Begintest () {
  Serial.println(F("READY TEST"));
  Serial.println(F("Commands:"));
  Serial.println(F("  START | STOP | RUN"));
  Serial.println(F("  SET F <idx> MIN <v>"));
  Serial.println(F("  SET F <idx> MAX <v>"));
  Serial.println(F("  GET F <idx>"));
  Serial.println(F("Notes:"));
  Serial.println(F("  - idx in [0..NUM_FADERS-1]"));
  Serial.println(F("  - Data stream: CSV <t_ms> <f> <val8> (one line per fader)"));
}

// Petite aide pour envoyer une ligne CSV exploitable par Python
static inline void comms_csv(uint32_t t_ms, int f, int v8) {
  Serial.print(F("CSV "));
  Serial.print(t_ms); Serial.print(' ');
  Serial.print(f);    Serial.print(' ');
  Serial.println(v8);
}

// Lecture d'une ligne via comms_* et parsing des commandes
static inline bool test1_fader_ADCLoopOncetest1(bool &armed) {
  if (!comms_available_line()) return false;
  String line = comms_take_line();
  line.trim();
  if (line.length()==0) return false;

  if (line.equalsIgnoreCase("START")) {
    armed = true;
    Serial.println(F("OK START"));
  } else if (line.equalsIgnoreCase("STOP")) {
    armed = false;
    Serial.println(F("OK STOP"));
  } else if (line.equalsIgnoreCase("RUN")) {
    if (armed) Serial.println(F("OK RUN"));
    else Serial.println(F("ERR NOT STARTED"));
    return armed; // signale au loop que l'on peut streamer
  } else if (line.startsWith("SET ")) {
    int idx, val;
    if (sscanf(line.c_str(), "SET F %d MIN %d", &idx, &val)==2 && idx>=0 && idx<NUM_FADERS) {
      gCalib.fader[idx]._usable_min = val; Serial.println(F("OK SET MIN"));
    } else if (sscanf(line.c_str(), "SET F %d MAX %d", &idx, &val)==2 && idx>=0 && idx<NUM_FADERS) {
      gCalib.fader[idx]._usable_max = val; Serial.println(F("OK SET MAX"));
    } else {
      Serial.println(F("ERR BAD SET"));
    }
  } else if (line.startsWith("GET ")) {
    int idx;
    if (sscanf(line.c_str(), "GET F %d", &idx)==1 && idx>=0 && idx<NUM_FADERS) {
      Serial.print(F("F ")); Serial.print(idx);
      Serial.print(F(" MIN="));  Serial.print(gCalib.fader[idx]._usable_min);
      Serial.print(F(" MAX="));  Serial.println(gCalib.fader[idx]._usable_max);
    } else {
      Serial.println(F("ERR BAD GET"));
    }
  } else {
    Serial.println(F("ERR UNKNOWN"));
  }
  return false;
}

// Appelé quand le test est armé
static inline void test1_fader_ADCrun() {
  // 1) Mettre à jour les faders (valeurs stockées dans gLastRaw/gLastOut8)
  ADC_FADER();

  // 2) Stream CSV pour Python (valeur 8 bits dans le temps)
  uint32_t t = millis();
  for (int i = 0; i < NUM_FADERS; ++i) {
    comms_csv(t, i, gLastOut8[i]);
  }

  // 3) Affichage OLED optionnel (4 lignes: F#:val)
#ifdef HAVE_OLED
  static uint32_t last = 0;
  if (millis() - last > 33) { // ~30 FPS max
    last = millis();
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    for (int i = 0; i < NUM_FADERS && i < 6; ++i) { // 6 lignes max lisibles
      display.setCursor(0, i*10);
      display.print(F("F")); display.print(i);
      display.print(F(": "));
      display.print(gLastOut8[i]);
    }
    display.display();
  }
#endif
}

static inline void runtest1() {
  static bool armed = false;

  if (test1_fader_ADCLoopOncetest1(armed)) {
    // hook: on pourrait reset des compteurs si besoin
  }

  if (armed) {
    test1_fader_ADCrun();
  }
}

#endif // TEST == 1