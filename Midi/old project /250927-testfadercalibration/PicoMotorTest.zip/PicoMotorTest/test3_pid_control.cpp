#include <Arduino.h>
#include "display.h"
void run_test3() {
  display_status("Test3 (stub)", "A completer", "");
  delay(200);
}
