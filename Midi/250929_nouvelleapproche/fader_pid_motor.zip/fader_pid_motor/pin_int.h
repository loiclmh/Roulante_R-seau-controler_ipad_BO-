/*  
    partie à faire récupérer tout les pin du pico 
    uttilsier pour centraliser toute les données
*/
