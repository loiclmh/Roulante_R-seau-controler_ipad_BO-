#include "debug.h"
#include <Arduino.h>

// ================================= variable pour débug programe =========================

// variable pour activer les print de debug dans les fichiers .cpp
extern bool on_debug;  // active ou non les print dans pid.cpp
extern bool on_debug_python = true; // active ou non les print dans motor.cpp
extern bool on_debug_monitorarduino = true; // active ou non les print dans bash_test.cpp

// ======================== variable pour le mode test =========================
// 0 = OFF (rien), 1 = TEST LOCAL (séquence 5-50-25-95-75-0), 2 = PYTHON (réglages via série)
extern uint8_t bash_test_mode = 0; 

//====================== DEBUG FADER ADC =====================
extern int debugOLED_fader = 1; // 0=off, 1=affiche valeurs ADC dans le moniteur série
extern int debug_fadermoniteur = 0; // 0=off, 1=affiche ready sur le moniteur 


void debugsetup() {
  if (on_debug) return;
  on_debug_python = false;
  on_debug_monitorarduino = false;
  debugOLED_fader = 0;
  debug_fadermoniteur = 0;
}